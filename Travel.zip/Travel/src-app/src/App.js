import './App.css';
import IndexHeader from './components/Header/IndexHeader';
import SectionIndex from './components/HeroContent/SectionIndex'

function App() {
  return (   
    <div>
      <IndexHeader/>
      <SectionIndex/>
    </div>
  );
}
export default App;